package r;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class RTest3 {

	public static void main(String[] args) throws Exception {
		RConnection c = new RConnection("70.12.113.223");
		c.setStringEncoding("utf8");
		System.out.println("Connection OK");
		c.eval("source('C:/R/workspace/day04/remote.R', encoding = 'UTF-8')");

		REXP rexp = c.eval("r3()");
		RList rlist = rexp.asList();
		String years[] = rlist.at("year").asStrings();
		double datas[] = rlist.at("data").asDoubles();
		for (int i = 0; i < years.length; i++) {
			System.out.println(years[i] + " : " + datas[i]);
		}
		
		JSONArray ja = new JSONArray();

		for (int i = 0; i < years.length; i++) {
			JSONObject jo = new JSONObject();
			jo.put("year",years[i]);
			jo.put("data",datas[i]);
			ja.add(jo);
		}

		System.out.println(ja.toJSONString());
		// [{"year":"2015","data":"980"},{}]
		// 1.JSON Library
		// 2.JSONArray, JSONObject
		// 3.toString
	
	}

}
