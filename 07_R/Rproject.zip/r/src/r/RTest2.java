package r;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;

public class RTest2 {

	public static void main(String[] args) 
	throws Exception{
		RConnection c = new RConnection("70.12.113.223");
		c.setStringEncoding("utf8");
		System.out.println("Connection OK");
		c.eval("source('C:/R/workspace/day04/remote.R', encoding = 'UTF-8')");
		
		REXP rexp = c.eval("r2()");
		double d[] = rexp.asDoubles();
		for(double dd:d) {
			System.out.println(dd);
		}
		c.close();
	}

}







