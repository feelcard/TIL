package r;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.Rserve.RConnection;

public class RTest1 {
//
	public static void main(String[] args) 
	throws Exception{
		RConnection c = new RConnection("70.12.113.223");
		c.setStringEncoding("utf8");
		System.out.println("Connection OK");
		c.eval("source('C:/R/workspace/day04/remote.R', encoding = 'UTF-8')");
		double x = 10;
		double y = 5;
		REXP rexp = c.eval("r1("+x+","+y+")");
		double result = rexp.asDouble();
		System.out.println("Result: "+result);
		c.close();
	}

}







