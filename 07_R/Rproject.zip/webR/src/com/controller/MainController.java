package com.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.RList;
import org.rosuda.REngine.Rserve.RConnection;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {

	@RequestMapping("/main.mc")
	public ModelAndView main() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("main");
		return mv;
	}

	@RequestMapping("/chart1.mc")
	public ModelAndView chart1() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("chart1");
		return mv;
	}

	@RequestMapping("/chart1data.mc")
	@ResponseBody
	public void chart1data(HttpServletResponse res) throws Exception {
		String result = "";
		RConnection con = new RConnection();
		con.eval("source('C:/R/workspace/day04/remote.R', encoding = 'UTF-8')");
		REXP rexp = con.eval("r3()");
		RList rlist = rexp.asList();
		String years[] = rlist.at("year").asStrings();
		double datas[] = rlist.at("data").asDoubles();
		JSONArray ja = new JSONArray();
		for (double d : datas) {
			ja.add(d);
		}
		res.setContentType("text/json; charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.print(ja.toJSONString());
		out.close();
		con.close();
	}

	@RequestMapping("/chart2.mc")
	public ModelAndView chart2() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("chart2");
		return mv;
	}

	@RequestMapping("/chart2data.mc")
	@ResponseBody
	public void chart2data(HttpServletResponse res) throws Exception {
		String result = "";
		RConnection con = new RConnection();
		con.eval("source('C:/R/workspace/day04/remote.R', encoding = 'UTF-8')");
		REXP rexp = con.eval("r6()");
		RList rlist = rexp.asList();
		double datas1[] = rlist.at("data1").asDoubles();
		double datas2[] = rlist.at("data2").asDoubles();
		double datas3[] = rlist.at("data3").asDoubles();
		double datas4[] = rlist.at("data4").asDoubles();
		double datas5[] = rlist.at("data5").asDoubles();
		JSONArray ja1 = new JSONArray();
		JSONArray ja2 = new JSONArray();
		JSONArray ja3 = new JSONArray();
		JSONArray ja4 = new JSONArray();
		JSONArray ja5 = new JSONArray();
		JSONArray jaa = new JSONArray();
		for (double d : datas1) {
			ja1.add(d);
		}
		jaa.add(ja1);
		for (double d : datas2) {
			
			ja2.add(d);
		}
		jaa.add(ja2);
		for (double d : datas3) {
		;
			ja3.add(d);
		}
		jaa.add(ja3);
		for (double d : datas4) {
			
			ja4.add(d);
		}
		jaa.add(ja4);
		for (double d : datas5) {
		
			ja5.add(d);
		}
		jaa.add(ja5);
		
		res.setContentType("text/json; charset=UTF-8");
		PrintWriter out = res.getWriter();
		System.out.println(jaa.toJSONString());
		out.print(jaa.toJSONString());
		out.close();
		con.close();
	}

}
