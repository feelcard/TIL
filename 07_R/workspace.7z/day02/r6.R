tt <- read.csv("titanic.csv",
                 header=T,
                 stringsAsFactors = F,
                 na.strings = "NA",
                 encoding = "UTF-8");
na.omit(tt);
tt2 <-
  tt[tt$survived >= 1 & is.na(tt$survived) == F, ]
aggregate(data=tt2,age~pclass+sex,mean)





