saveFile <- function(d){
  write.csv(
    d,
    file="userAvg.csv",
    row.names=T,
    fileEncoding = "EUC-KR"
  );
}
ua <- function(){
  user <- read.csv("user.csv",
                 header=F,
                 stringsAsFactors = F,
                 na.strings = "NA",
                 encoding = "EUC-KR");
  colnames(user) <- 
  c("ID","NAME","AGE","WEIGHT","HEIGHT");
  usera <- apply(user[,c(-1,-2)],2,mean,na.rm=T)
  saveFile(usera);
 
  return (usera);
}



