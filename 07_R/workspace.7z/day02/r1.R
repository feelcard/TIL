gr <- function(){
  library(ggplot2)
  
  qplot(data=mpg,x=hwy);
}