ss <- read.csv("student.csv",
               header=T,
               stringsAsFactors = F,
               na.strings = "NA",
               encoding = "EUC-KR");
ss$avg <- apply(ss[,c(-1,-2)],1,mean,na.rm=T)
ss[ss$avg >= mean(ss$avg),c(2,7)]
ss$grade <- ifelse(ss$avg >= 90,'A',
               ifelse(ss$avg >= 85,'B',
                  ifelse(ss$avg >= 80,'C','D')      
               )       
            )
table(ss$grade)
ss2 <- ss[order(ss$avg,decreasing = T),]
ss2$level <- c(1:8)
ss2[ss2$level <= 5,]




