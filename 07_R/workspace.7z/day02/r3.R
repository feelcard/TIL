df1 <- data.frame(
  name=c("kim","lee","han"),
  en=c(90,98,78),
  ma=c(98,89,78),
  class=c(1,1,2),
  stringsAsFactors = F
)
df1$avg <- apply(df1[,c(-1,-4)],1,mean)

apply(df1[,c(-1,-4)],2,mean)
