View(mpg)
m1 <- aggregate(displ~class,mpg,mean)
