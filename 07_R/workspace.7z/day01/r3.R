v1 <- c(1:3)
names(v1) <- c("a","b","c")
names(v1)[2]
v1[2]
v2 <- c(1:3)
lengths(v1)
length(v1)
NROW(v1)
nrow(v1)



