# n:1 국가별 평균 날씨를 Vector로 리턴한다.
# n:2 분기별 평균 날씨를 Vector로 리턴한다.
# 단 2개 모두 컬럼 명칭을 정확히 셋팅해서 
# 리턴 한다.

re <- function(n){
  w <- data.frame(nation=c("ko","jp","ch"),
                  Q1=c(30,20,20),
                  Q2=c(31,18,19),
                  Q3=c(28,18,12),
                  Q4=c(22,16,20),
                  stringsAsFactors = FALSE);
  result <- NULL;
  if(n == 1){
    result <- rowMeans(w[,-1]);
    names(result) <- w$nation; 
  }else{
    result <- colMeans(w[,-1]);
  }
  
  return (result);
}



