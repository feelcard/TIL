af <- function(a1,a2,a3,a4){
  v1 <- a1;
  v2 <- a2;
  v3 <- a3;
  v4 <- a4;
  result <- v1+v2+v3+v4;
  return (result);
} 