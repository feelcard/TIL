a <- 100
gubun <- factor("대",c("대","중","소"))
