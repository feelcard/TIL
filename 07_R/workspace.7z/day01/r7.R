f1 <- function(a){
  result <- NULL;
  if(a %% 2 == 0){
    result = "even";
  }else{
    result = "odd";
  }
  return (result);
}
me.f2 <- function(n){
  result <- 0;
  for(i in c(1:n)){
    print(i);
    result <- result + i;
  }
  return (result);
}







