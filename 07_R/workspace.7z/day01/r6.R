n <- c("na","hy","mi","ha")
e <- c(90,90,98,89)
m <- c(98,89,91,81)
k <- c(99,100,91,82)
s <- c(99,97,88,87)

c1 <- data.frame(name=n,en=e,ma=m,ko=k,si=s,
                 stringsAsFactors = FALSE)

c1[5,] <- c("yu",NA,NA,NA,NA)

sum(as.numeric(c1[,3]),na.rm = TRUE)



#각 과목의 평균을 Vector로 만들어라 
rm <- rowSums(c1[,-1],na.rm = TRUE)
cm <- colMeans(c1[,-1],na.rm = TRUE)
# 모든과정의 평균과 모든 학생의 평균을 구하시오
mean(rm)
mean(cm)




