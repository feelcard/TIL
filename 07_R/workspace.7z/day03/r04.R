audi <- mpg[mpg$manufacturer %in% "audi",]
audi <- mpg[order(audi$hwy,decreasing = T) , ]
audi <- head(audi,5)
install.packages("sqldf")
library(sqldf)

hd <- sqldf("SELECT model, hwy FROM mpg 
            WHERE MANUFACTURER = 'hyundai'
            ORDER BY hwy DESC");
hd2 <- sqldf("SELECT MANUFACTURER, count(*) AS CNT               FROM mpg 
            GROUP BY MANUFACTURER
            HAVING count(*) > 20");
class(hd2)

