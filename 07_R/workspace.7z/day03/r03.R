g3 <- function(){
  md <- table(mpg$drv);
  md <- as.data.frame(md);
  return(md);
}