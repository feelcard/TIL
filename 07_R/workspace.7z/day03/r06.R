install.packages("rJava")
install.packages("KoNLP")
install.packages("dplyr")
install.packages("stringr")
install.packages("wordcloud")
install.packages("RColorBrewer")

library("KoNLP")
library("dplyr")
library("stringr")
library("wordcloud")
library("RColorBrewer")

txt <- readLines("news.txt",encoding = "UTF-8");
txt <- str_replace_all(txt,"\\W"," ")
txt <- str_replace_all(txt,"[0-9]"," ")
txt <- str_replace_all(txt,"[a-z]"," ")
txt <- str_replace_all(txt,"[A-Z]"," ")
non <- extractNoun(txt)
cnt <- table(unlist(non))
df_cnt <- as.data.frame(cnt,stringsAsFactors = F)
colnames(df_cnt) <- c("word","cnt")
df_cnt <- df_cnt[nchar(df_cnt$word) >= 2,]
wc <- df_cnt[order(df_cnt$cnt,decreasing = T),]
wc <- head(wc,20)
#ggplot(data=wc,aes(x=wc$word,y=wc$cnt)) +geom_col()
pal <- brewer.pal(8,"Dark2")

jpeg("wc.jpeg",width=800,height=600,quality=100)
wordcloud(
  words = wc$word,
  freq = wc$cnt,
  min.freq = 2,
  max.words=200,
  random.order =F,
  random.color = T,
  rot.per = 1,
  scale = c(4, 0.3),
  colors = pal
  
)
dev.off()










