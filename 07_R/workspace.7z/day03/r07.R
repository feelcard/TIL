install.packages("ggplot2")
install.packages("plotly")

library(ggplot2)
library(plotly)
p <- ggplot(data=mpg, aes(x=displ,y=hwy,col=drv)) + geom_point()
ggplotly(p)

