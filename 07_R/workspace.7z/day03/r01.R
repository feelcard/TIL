g1 <- function(){
  library(ggplot2);
  ggplot(data=mpg,aes(x=displ,y=hwy))+geom_point()
  +xlim(3,6)+ylim(10,30);
}

