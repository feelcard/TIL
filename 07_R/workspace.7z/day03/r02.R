g2 <- function(){
  library(ggplot2);
  hd = aggregate(data=mpg, hwy~drv ,mean, na.rm=T);
  colnames(hd) <- c("drv","mean_hwy");
  ggplot(data=hd, aes(x=hd$drv,y=hd$mean_hwy))+geom_col();
}