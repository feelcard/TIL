install.packages("rJava")
install.packages("RJDBC")
install.packages("DBI")

library(rJAva)
library(RJDBC)
library(DBI)
drv <- JDBC(driverClass = "oracle.jdbc.driver.OracleDriver",classPath = "c:\\lib\\ojdbc6.jar");
conn <- dbConnect(drv,"jdbc:oracle:thin:@70.12.113.220:1521:xe","db","db");
tuser <- dbGetQuery(conn,"SELECT * FROM USERS");
dbDisconnect(conn);

