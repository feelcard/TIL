package app;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.frame.Service;
import com.vo.Product;
import com.vo.UserVO;

public class ProductInsert {

	public static void main(String[] args) {
		// Start Spring Container
		AbstractApplicationContext factory
		= new GenericXmlApplicationContext("spring.xml");
		
		Service<String,Product> biz = 
			(Service)factory.getBean("pbiz");
		Product p = new Product(0, "pp", 1000, "pp.jpg");
		try {
			int r = biz.register(p);
			System.out.println("Register OK"+p.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		factory.close();
	}

}



