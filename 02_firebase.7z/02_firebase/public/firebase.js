// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyAbirE-nI5_0Vchqz6sJpjzQaED33uoM54",
    authDomain: "study-946bb.firebaseapp.com",
    databaseURL: "https://study-946bb.firebaseio.com",
    projectId: "study-946bb",
    storageBucket: "study-946bb.appspot.com",
    messagingSenderId: "262608052759",
    appId: "1:262608052759:web:3d0e90975cba375ab43252",
    measurementId: "G-MQKHHZ2LKF"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig); 